# Test Data 
dimesion (samples, channels, timepoints)  
filename: test-data.npy

# Test Label
dimesion (samples, )  
filename: test-label.npy


